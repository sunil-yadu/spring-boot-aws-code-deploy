#!/bin/bash
sudo pkill -f 'java -jar'
