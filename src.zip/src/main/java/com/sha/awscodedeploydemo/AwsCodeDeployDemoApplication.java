package com.sha.awscodedeploydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsCodeDeployDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsCodeDeployDemoApplication.class, args);
	}

}
