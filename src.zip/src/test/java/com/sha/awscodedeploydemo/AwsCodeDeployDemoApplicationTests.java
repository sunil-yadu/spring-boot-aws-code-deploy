package com.sha.awscodedeploydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsCodeDeployDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
