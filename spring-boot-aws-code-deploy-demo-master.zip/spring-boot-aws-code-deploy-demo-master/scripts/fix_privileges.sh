#!/usr/bin/env bash
chmod +x /home/ec2-user/server/* jar
chmod +x /home/ec2-user/server/server_start.sh
chmod +x /home/ec2-user/server/server_stop.sh
